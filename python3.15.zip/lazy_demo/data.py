"""Data submodule."""
print("📊 lazy_demo.data loaded!")

DATASET = [1, 2, 3, 4, 5]
