"""A module that raises ZeroDivisionError when imported."""
print("💥 lazy_demo.broken_dep is being imported and will raise an error...")
1/0
