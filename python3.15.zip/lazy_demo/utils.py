"""Utility submodule."""
print("🔧 lazy_demo.utils loaded!")

def helper():
    """A helper function."""
    return "Helper function result"
